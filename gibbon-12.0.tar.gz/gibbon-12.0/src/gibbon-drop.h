/*
 * This file is part of gibbon.
 * Gibbon is a Gtk+ frontend for the First Internet Backgammon Server FIBS.
 * Copyright (C) 2009-2012 Guido Flohr, http://guido-flohr.net/.
 *
 * gibbon is free software: you can redistribute it and/or modify 
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * gibbon is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with gibbon.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef _GIBBON_DROP_H
# define _GIBBON_DROP_H

#ifdef HAVE_CONFIG_H
# include <config.h>
#endif

#include <glib.h>
#include <glib-object.h>

#include "gibbon-game-action.h"

#define GIBBON_TYPE_DROP \
        (gibbon_drop_get_type ())
#define GIBBON_DROP(obj) \
        (G_TYPE_CHECK_INSTANCE_CAST ((obj), GIBBON_TYPE_DROP, \
                GibbonDrop))
#define GIBBON_DROP_CLASS(klass) (G_TYPE_CHECK_CLASS_CAST ((klass), \
        GIBBON_TYPE_DROP, GibbonDropClass))
#define GIBBON_IS_DROP(obj) \
        (G_TYPE_CHECK_INSTANCE_TYPE ((obj), \
                GIBBON_TYPE_DROP))
#define GIBBON_IS_DROP_CLASS(klass) \
        (G_TYPE_CHECK_CLASS_TYPE ((klass), \
                GIBBON_TYPE_DROP))
#define GIBBON_DROP_GET_CLASS(obj) \
        (G_TYPE_INSTANCE_GET_CLASS ((obj), \
                GIBBON_TYPE_DROP, GibbonDropClass))

/**
 * GibbonDrop:
 *
 * One instance of a #GibbonDrop.  All properties are private.
 */
typedef struct _GibbonDrop GibbonDrop;
struct _GibbonDrop
{
        GibbonGameAction parent_instance;
};

/**
 * GibbonDropClass:
 *
 * Abstraction for a dropped cube!
 */
typedef struct _GibbonDropClass GibbonDropClass;
struct _GibbonDropClass
{
        /* <private >*/
        GibbonGameActionClass parent_class;
};

GType gibbon_drop_get_type (void) G_GNUC_CONST;

GibbonDrop *gibbon_drop_new ();

#endif
